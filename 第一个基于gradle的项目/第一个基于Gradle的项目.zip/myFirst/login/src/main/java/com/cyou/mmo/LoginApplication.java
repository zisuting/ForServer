package com.cyou.mmo;

import org.slf4j.LoggerFactory;

public class LoginApplication {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LoginApplication.class);
    public static void main(String[] args) throws InterruptedException, Exception {
        LOGGER.info("This is myFrist project!");

    }
}
